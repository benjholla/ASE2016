/* stub added to keep compilation happy */

void panic(char * s){}