/* xdone.c - xdone */

/*------------------------------------------------------------------------
 * xdone  --  print system completion message as last process exits
 *------------------------------------------------------------------------
 */
xdone()
{
        printf("\n\nAll user processes have completed.\n\n");

}
