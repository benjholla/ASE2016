/* stub for compilation w/o assembly */

void setclkr(){}
